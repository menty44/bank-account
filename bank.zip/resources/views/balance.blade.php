@extends('layouts.base')

@section('title', 'Check Bank Balance')


@section('content')
<h3>Your account balance</h3>
&#x24; {{$balance}}
@endsection
